test = {   'name': 'q5_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(smallest_change_major, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> smallest_change_major == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

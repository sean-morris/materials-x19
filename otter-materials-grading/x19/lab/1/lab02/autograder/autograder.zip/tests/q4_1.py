test = {   'name': 'q4_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 1 <= jobs_q1 <= 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> jobs_q1 == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
